GeoServer 2.9+ H2 Data Store Extension
======================================

This package contains a H2 DataStore implementation that is
distributed as a separate plug-in.

For more information http://docs.geoserver.org/latest/en/user/data/database/h2.html

Installation
------------

  1. Unzip this archive into the GeoServer library directory. In the binary
     install this is under '<GEOSERVER_ROOT>/webapps/geoserver/WEB-INF/lib'.

  2. Restart GeoServer.

